package org.amit;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;
import java.util.logging.Logger;

/**
 * Created by Amittank on 1/22/2017.
 *
 * This TextAnalyzer analyzes a text passed to it and log the length of the word and periodically user can call
 * for report of words sorted by number of characters and by ASCII with number of occurences.
 *
 * Assumption: All the errors are logged as warning thinking it is a utility and should not throw any error
 * But this behavior totally depends on the use case.
 *
 * Assumption: All the numbers are kept as an Integer. Can be changed.
 */
public class TextAnalyzer {

    Logger LOGGER = Logger.getLogger("TextAnalyzer.class");
    // Keeping this Map global so that whenever report is required, Information can be extracted from this Map.
    private Map<Integer, TreeMap<String, Integer>> GLOBAL_MAP = new HashMap<Integer, TreeMap<String, Integer>>();

    /**
     * This method takes input query string to analyze and Logs number of characters for each word.
     * @param queryString
     */
    public void analyze(String queryString) throws Exception {

        try {
            Properties properties = loadProperties();
            if(queryString != null && !queryString.isEmpty()){
                String[] words = queryString.split(" ");
                for (int index = 0; index < words.length; index++) {
                    //If global map have prior word with same number of characters
                    if (GLOBAL_MAP.get(words[index].toCharArray().length) != null) {
                        TreeMap<String, Integer> wordAndCounterMap = GLOBAL_MAP.get(words[index].toCharArray().length);
                        // If word already present in the map then increase the counter
                        if (wordAndCounterMap.get(words[index]) != null) {
                            wordAndCounterMap.put(words[index], wordAndCounterMap.get(words[index]) + 1);
                            GLOBAL_MAP.put(words[index].toCharArray().length, wordAndCounterMap);
                            LOGGER.info(String.format(words[index] + "  " + words[index].toCharArray().length));
                        } else { //If word not present then create a new record.
                            wordAndCounterMap.put(words[index], new Integer(1));
                            LOGGER.info(String.format(words[index] + "  " + words[index].toCharArray().length));
                        }
                    } else { //If global map have no prior word with same number of characters.
                        TreeMap<String, Integer> newMap = new TreeMap<String, Integer>();
                        newMap.put(words[index], new Integer(1));
                        GLOBAL_MAP.put(words[index].toCharArray().length, newMap);
                        LOGGER.info(String.format(words[index] + "  " + words[index].toCharArray().length));
                    }
                }
            }else{
                LOGGER.warning(properties.getProperty("EmptyString"));
            }
        } catch (IOException ioException) {
           LOGGER.warning("Error reading properties file to load constants");
            throw ioException;
        } catch (Exception exception){
            LOGGER.warning("The following error occurred while analyzing text :" + exception);
            throw exception;
        }
    }

    /**
     * This method prints the words and input in the text analyzer and its number of occurences in the sorted order
     * Sorting is by length of the word first and by ASCII after that.
     */
    public void printReport() throws Exception {
        try{
            Properties properties = loadProperties();
            if(!GLOBAL_MAP.isEmpty()){
                for (Integer key : GLOBAL_MAP.keySet()) {
                    TreeMap<String, Integer> innerMap = GLOBAL_MAP.get(key);
                    for (String word : innerMap.keySet()) {
                        LOGGER.info(String.format(innerMap.get(word) + "  " +word));
                    }
                }
            }else{
                LOGGER.warning(properties.getProperty("NoStringAnalyzed"));
            }
        }catch(Exception exception){
            LOGGER.warning("The following error occurred while analyzing text :" + exception);
            throw exception;
        }
    }

    /**
     * Load properties
     * @return
     * @throws IOException
     */
    private Properties loadProperties() throws IOException {
        Properties properties =  new Properties();
        properties.load(new FileInputStream("src/main/resources/Constants.properties"));
        return properties;
    }
}