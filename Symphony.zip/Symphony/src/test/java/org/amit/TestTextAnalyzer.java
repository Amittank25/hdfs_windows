package org.amit;

import junit.framework.TestCase;
import org.junit.Test;

/**
 * Created by Amittank on 1/22/2017.
 *
 * Assumption: Keeping only one positive case. Can add more positive cases when needed.
 * Assumption: As
 *
 */

public class TestTextAnalyzer extends TestCase {

    @Test
    public void testAnalyze(){
        try{
            TextAnalyzer analyzer = new TextAnalyzer();
            analyzer.analyze("The quick brown fox jumped over the lazy brown dog's back");
            analyzer.printReport();
        }catch (Exception exception){
            assertNull(exception);
        }
    }

    @Test
    public void testAnalyzeWithEmptyString(){
        try{
            TextAnalyzer analyzer = new TextAnalyzer();
            analyzer.analyze("");
        }catch (Exception exception){
            assertNotNull(exception);
        }
    }

    @Test
    public void testAnalyzeWithNullString(){
        try{
            TextAnalyzer analyzer = new TextAnalyzer();
            analyzer.analyze(null);
        }catch (Exception exception){
            assertNotNull(exception);
        }
    }

    @Test
    public void testGetReportWithNullOrEmptyString(){
       try{
           TextAnalyzer analyzer = new TextAnalyzer();
           analyzer.printReport();
       }catch (Exception exception){
           assertNotNull(exception);
       }
    }
}
